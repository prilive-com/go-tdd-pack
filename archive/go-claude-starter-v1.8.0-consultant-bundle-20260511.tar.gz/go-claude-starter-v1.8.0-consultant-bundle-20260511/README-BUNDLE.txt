go-claude-starter — consultant bundle
======================================

Date: 2026-05-11
Current release: v1.8.0 (commit 2ab3d7b)
Smoke baseline: 520 / 0 passing

READ ORDER
----------

00-READ-FIRST_CONSULTANT_BRIEF.md
    Single entry point. Tells you what the project is, why,
    how we develop it, how it works, where we are. Read first
    top-to-bottom.

01-AI_DEVELOPER_GUIDE.md
    The user-facing onboarding doc (711 lines). Install, setup,
    daily workflows, stable error codes, killswitches.

02-RELEASE_GUIDE.md
    Current release notes + update paths from prior versions
    + maintainer instructions.

SNAPSHOT.txt
    Tree summary, file counts, smoke baseline.

GIT_LOG.txt
    59 commits, oneline format.

GIT_LOG_with_stats.txt
    Full git log with per-commit file stats (large; for deep audit).

repo/
    The full codebase as of 2026-05-11.
    - .claude/    Auto-loaded by Claude Code (rules, skills, agents, hooks)
    - .tdd/       TDD ceremony state machine + cycle artifacts
    - scripts/    CI utilities + TDD smoke + AST helper (Go)
    - docs/       Specs (v1.6.0/v1.7.0/v1.8.0), guides, workflow
    - specs/      Layer 0 spec gate samples
    - examples/   Worked TDD cycle examples
    - archive/    Historical state snapshots

VERIFICATION
------------

To verify the smoke baseline:
    cd repo
    bash scripts/tdd-test-hooks.sh 2>&1 | tail -3
    # Expect: Results: 520 passed, 0 failed

Prerequisites: bash 5+, jq, git, Go 1.26.2+.
