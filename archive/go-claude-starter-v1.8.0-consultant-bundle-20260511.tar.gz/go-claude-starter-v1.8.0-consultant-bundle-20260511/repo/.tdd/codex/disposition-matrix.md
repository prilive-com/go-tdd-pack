# Concern Disposition Matrix — v1.6.2-marker-drift-and-pass-a-docs

date: 2026-05-10T00:00:00Z
cycle_id: v1.6.2-marker-drift-and-pass-a-docs
findings_total: 27
codex_session: ephemeral (27 rounds; rounds 21 + 25 PUSHBACK; round 27 clean)
codex_model: gpt-5.5 (gpt-5.4 fallback once)
review_phase: diff

## Cross-cutting observations

27 rounds of /second-opinion on a small (~200 line) cycle. The diff
adds two scripts (schema-context generator + marker-drift
preprocessor), edits one Tier 1 file (SKILL.md prompt + sanitizer),
and updates two doc files. Hook semantics are unchanged.

The dominant pattern across the rounds: the marker-drift
preprocessor's keyword-matching architecture has a fundamental limit
— natural-language phrasings of "drift findings" overlap with
"real governance defect findings" in ways no regex can perfectly
distinguish. Each round Codex found a slightly different phrasing
that slipped through the matcher; each fix narrowed the matcher
further. By round 27 the matcher accepts only 5 explicit gate-
subject demand phrases and excludes 13 historical phrasings.

Two PUSHBACK rounds (21, 25) acknowledge the architectural limit
explicitly: the matcher cannot distinguish drift from defect when
both mention `Repo instructions require` + a file path. The
discipline contract (agent verifies hook file when path is named
in finding) is the actual protection — round 26 added that
verification requirement to go-tdd.md.

The cycle also added defense-in-depth on provenance: rounds 6, 7,
9, 10, 11, 13, 16, 17, 19, 20, 22 progressively tightened the
sanitizer to handle invalid JSON, jq missing, JSON escape variants,
forged caller-supplied fields, and cross-config validation.

## Findings table

| ID | Source | Severity | Concern (1 line) | Disposition | Reason | Spec change |
|----|--------|----------|------------------|-------------|--------|-------------|
| F1 | R1 | P1 | Preprocessor flagged inverse-direction findings (its own meta-finding) | ACCEPT | Round 1 caught the preprocessor flagging Codex's own meta-analysis. Tightened predicate to require gate-subject demand + exclude deprecation vocab. The class became the recurring theme of rounds 2-25. | yes |
| F2 | R2 | P1 | "still requires X; canonical is Y" inverse without "deprecated" | ACCEPT | Added inverse-direction detection: "(canonical|...) ... green phase authorized" near old marker excludes. | yes |
| F3 | R3 | P0 | "plan uses X; required is Y" — demand AFTER old marker | ACCEPT | Order-sensitive matching: demand vocab must precede old marker within 80 chars (negative lookahead for green phase between). | yes |
| F4 | R3 | P0 | Stale cached context cat-ed when generator absent | ACCEPT | Combined check: `_gen + _ctx_file + tdd-config.json` all present before catting. | yes |
| F5 | R3 | P1 | Generator footer hardcoded v1.6.0 rename even when marker_aliases empty | ACCEPT | Conditional footer based on `marker_aliases` presence. Customized downstream repos see only generic guidance. | yes |
| F6 | R4 | P1 | Preprocessor citation hardcoded; not bound to local config | ACCEPT | Read `tdd-config.json` at runtime; cite local marker_aliases mapping. Empty mapping → pass through unchanged. | yes |
| F7 | R4 | P2 | SKILL.md cat'd cached context when config missing | ACCEPT | Added `[ -f .tdd/tdd-config.json ]` to the cat condition. | yes |
| F8 | R5 | P1 | "canonical NEW replaced OLD" inverse phrasing | ACCEPT | Added "old marker" / "replaced human approved" to deprecation-exclusion vocab. | yes |
| F9 | R5 | P2 | jq-missing generator emitted authoritative-looking empty context | ACCEPT | Generator emits explicit "TOOLING DEGRADED" block + exits 0. | yes |
| F10 | R6 | P1 | Caller-supplied auto_pushback_eligible survived preprocessor | ACCEPT | Strip reserved fields BEFORE matching; add back only on verified match. | yes |
| F11 | R6 | P1 | "Plan requires" plan-subject false positive | ACCEPT | Added plan-subject exclusion: `(plan|the plan)( still|...)? (uses|requires|...) ... human approved implementation`. | yes |
| F12 | R6 | P2 | Generator partial-write race | ACCEPT | Atomic write: tmp + mv pattern. Both regular and DEGRADED branches. | yes |
| F13 | R7 | P1 | SKILL.md sanitizer skipped when jq missing | ACCEPT | Added explicit warning when jq missing; fail-closed if reserved fields present. | yes |
| F14 | R7 | P1 | Bare "marker is" demand phrase | ACCEPT | Dropped from demand vocab (over-broad); broader exclusion covers legitimate inverse cases. | yes |
| F15 | R8 | P1 | Stale cached context after failed regen | ACCEPT | Added mtime freshness check: cached file must be NEWER than both generator and config. | yes |
| F16 | R8 | P2 | Matcher under-matched "config requires" drift | ACCEPT | Added "tdd config requires", "config requires" to demand vocab. | yes |
| F17 | R8 | P2 | F9 SKILL.md threshold drift | ACCEPT | Documented per-round bumps with explicit justification. | no |
| F18 | R9 | P1 | jq-missing forged-field guard absent | ACCEPT | Added explicit warning + key-shape grep. | yes |
| F19 | R9 | P2 | "plan uses NEW" wrongly excluded by global "plan uses" rule | ACCEPT | Made plan-subject exclusion order-sensitive (plan-uses-OLD only). | yes |
| F20 | R10 | P1 | "for backwards compatibility" finding flagged | ACCEPT | Added "backwards compat", "in marker_aliases", "alias entry", "breaks old cycles", "preserve.*alias", "alias preservation" to exclusion. | yes |
| F21 | R10 | P2 | jq-missing fail-closed needed for forged-field case | ACCEPT | Added unconditional exit 1 when jq missing + reserved fields present. | yes |
| F22 | R11 | P1 | Negated demand "marker is NOT OLD" still flagged | ACCEPT | Negative lookahead: excludes `not human approved`, `is not human`, `isn't human` between demand and old marker. | yes |
| F23 | R11 | P2 | Sanitizer skipped on no-local-alias early-return | ACCEPT | Strip reserved fields BEFORE the early return path. | yes |
| F24 | R11 | P3 | F9 threshold inconsistency | ACCEPT | Updated comment + threshold to single value. | no |
| F25 | R12 | P2 | Stale-doc reference flagged | ACCEPT | Dropped bare "gate vocabulary"; added "current marker is" to inverse vocab. | yes |
| F26 | R13 | P1 | Sanitizer fail-open on malformed but valid JSON | ACCEPT | Added fail-closed branch: jq fails AND raw has reserved field keys. | yes |
| F27 | R13 | P2 | Bare "hook requires" potential false-positive | ACCEPT (caught by other exclusions empirically) | The "v1.6.0" deprecation exclusion catches typical phrasings. Negative regression test added. | no |
| F28 | R14 | P1 | "The hook requires Human approved" without "deprecated" vocab | ACCEPT | Dropped "hook requires", "ceremony requires", "gate requires" from demand vocab. | yes |
| F29 | R14 | P2 | canonical_citation lacked line number | ACCEPT | Added line-number lookup via grep on tdd-config.json marker_aliases entry. | yes |
| F30 | R15 | P2 | Doc honesty: matcher narrower than spec | ACCEPT | Added "Narrow-matching philosophy" section to go-tdd.md. | yes |
| F31 | R16 | P1 | "scripts/foo.sh requires the marker" file-subject false-positive (incidentally caught) | ACCEPT | Dropped "require the marker" from demand vocab as defense. | yes |
| F32 | R16 | P2 | jq-missing grep not JSON-key-shaped | ACCEPT | Updated grep to `(^|[{,])[[:space:]]*"key"[[:space:]]*:` — matches only JSON key positions. | yes |
| F33 | R17 | P1 | jq-missing grep missed pretty-printed JSON | ACCEPT | Added `^` to grep alternatives; matches keys at line-start. | yes |
| F34 | R17 | P2 | Preprocessor trusted alias presence without verifying CANONICAL is in required_markers_* | ACCEPT | Added cross-validation: CANONICAL must be in required_markers_*; OLD must NOT be in required_markers_*. | yes |
| F35 | R18 | P2 | "the alias" exclusion gap | ACCEPT | Added "alias.{0,30}human approved implementation" + "the alias" to exclusion. | yes |
| F36 | R19 | P2 | Lib header described broader matcher than implemented | ACCEPT | Rewrote CONTRACT comment to enumerate active phrases + dropped phrases explicitly. | yes |
| F37 | R19 | P2 | jq-missing grep didn't handle escape variants | ACCEPT | Extended grep to handle `_` underscore escapes. | yes |
| F38 | R20 | P1 | "required marker is" still flagged hook defects | ACCEPT | Dropped from demand vocab. | yes |
| F39 | R20 | P2 | Escape variants required hard-fail when jq missing | ACCEPT | Unconditional fail-closed when jq missing; install jq is mandatory for /second-opinion to operate. | yes |
| F40 | R21 | P1 | (PUSHBACK) Codex misread doc comment as active matcher | PUSHBACK | Empirically verified: the matcher does NOT flag the case Codex described. Round-20 fix was already in place. Updated comment to be unambiguous about CURRENT vs DROPPED phrases. Regression test pinned. | no |
| F41 | R22 | P1 | Sanitizer hard-failed on invalid JSON (regression from r20) | ACCEPT | Split jq-missing (hard-fail) from jq-present-invalid-JSON (pass through per preprocessor contract). | yes |
| F42 | R22 | P2 | Subjectless "approval marker is" + "marker vocabulary is" | ACCEPT | Dropped both from demand vocab. | yes |
| F43 | R23 | P1 | Possessive "plan's gate vocabulary requires" | ACCEPT | Extended plan-subject exclusion to allow "(plan).?{0,40}(uses|requires|gate vocabulary)". | yes |
| F44 | R24 | P1 | Subjectless "the gate vocabulary is" | ACCEPT | Dropped from demand vocab. Final demand vocab has 5 explicit phrases. | yes |
| F45 | R25 | P1 | (PUSHBACK) "Repo instructions require X in scripts/path" indistinguishable from real defect | PUSHBACK | Acknowledged architectural limit. Documented in lib comment. The agent's verification step (read hook file when path named) is the actual protection. | no |
| F46 | R26 | P1 | go-tdd.md didn't require hook-file verification when finding cites a path | ACCEPT | Added "Hook-file verification (when the finding cites a path)" section to go-tdd.md "Known reviewer-drift findings". | yes |
| F47 | R27 | — | Zero findings — clean | — | Diff stable. | no |

## Pass A divergences

(Not applicable — Pass A flag stays false per cycle non-goal.)
