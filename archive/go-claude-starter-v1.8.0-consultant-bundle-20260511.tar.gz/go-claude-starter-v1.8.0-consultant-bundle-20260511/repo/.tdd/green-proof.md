# Green Proof: v1.8.0-ast-validator-and-audit-integrity

**Date:** 2026-05-11

## Output (verbatim — final smoke)

```text
Results: 520 passed, 0 failed
```

## What this green proves

520/0 across the full TDD smoke suite (483 baseline carried from
v1.7.0 + 14 v1.8.0 acceptance tests for the 8 ACs + 23 round-derived
RED tests across rounds 1-7 — every one transitioned RED → GREEN).

## Acceptance-criteria coverage (AC1 … AC8)

| AC | Surface | Smoke evidence |
|----|---------|----------------|
| AC1 | `scripts/tdd/ast/validator.go` (Go AST helper, 4 subcommands) | `v18_ast_*` (5 tests) |
| AC2 | Validator library AST dispatch (AND-gate with regex) | `v18_validator_dispatches_to_ast_helper`, `v18_validator_ast_killswitch_falls_back_to_regex` |
| AC3 | NEW `schema_predicate_correction` exception type | `v18_schema_predicate_correction_grant_and_validate`, every `v18_r*` schema test |
| AC4 | Per-cycle exception count cap | `v18_max_per_cycle_*` (2 tests) |
| AC5 | Audit-log sha-chain integrity | `v18_audit_chain_*` (3 tests + r4/r5/r6/r7 hardenings) |
| AC6 | Graceful degradation when AST unavailable | `v18_validator_no_go_binary_warns_and_falls_back` |
| AC7 | Smoke + spec doc | All 37 v1.8.0 tests + spec at `docs/specs/ast-validator-and-audit-integrity-v1.8.0-spec.md` |
| AC8 | Killswitch parity + decision table | `v18_validator_ast_killswitch_falls_back_to_regex` + go-tdd.md table |

## Review history (7 /second-opinion rounds)

25 P0/P1 findings ACCEPTED + 2 PUSHBACK (same finding flagged twice;
the helper's sha256 function was a codex false-positive). See
`.tdd/disposition-matrix.md` for per-finding adjudication.

| Round | Findings | Disposition |
|---|---|---|
| 1 | 3 P0 + 1 P1 | 3 ACCEPT, 1 PUSHBACK (sha256 false-positive) |
| 2 | 3 P0 | ACCEPT all (schema fail-closed; tokenizer; new-file synthesis) |
| 3 | 2 P0 + 1 P1 | ACCEPT all (deletions in import-block; scanner-based schema; punctuation carve-out) |
| 4 | 3 P0 + 1 P1 | ACCEPT all (audit deletion; scope-tightening; mech-sig-prop already passes; path collisions) |
| 5 | 4 P0 | ACCEPT all (--paths filtering; strict path matching; carve-out tightening; chain-started state) |
| 6 | 2 P0 + 1 P1 | 2 ACCEPT, 1 PUSHBACK (sha256 repeat false-positive) |
| 7 | 3 P0 | ACCEPT all (partial rename rejection; comment directive rejection; ID-set audit comparison) |

## Why not fake green

- Each round's RED test reproduces the codex bypass empirically with
  a real input fixture BEFORE the fix lands.
- After each fix, the same RED test transitions to PASS without
  changing the fixture — proves the fix actually closes the bypass
  class. 23/23 round-derived RED tests transitioned.
- The AST validator AND-gates regex (defense in depth). Even if AST
  has a false negative, regex still applies.
- Codex review is independent; PUSHBACK on the sha256 finding was
  empirically backed by the v18_audit_chain_grant_helper_writes_prev_sha
  test (two grant events in one cycle, chain intact).
- v1.7.0 baseline (483 tests) preserved unchanged — extending, not
  replacing.

## Known limits (v1.9 backlog)

The AST validator now AND-gates regex (v1.7.0). Remaining limits:

1. AST helper cold-start ~300ms per `go run`. Pack consumers can
   `go build` to amortize; v1.9 will detect a pre-built binary.
2. `schema-predicate-check` is line-by-line; multi-line renames
   must be split.
3. External audit head pin (binding into the artifact) would close
   the last-line edit edge case the chain alone misses.
4. Audit log archival/rotation — unbounded growth per cycle.
5. Encrypted/signed audit log — host-compromise protection v2.0+.
6. AST helper sandboxing — CLAUDE_PLUGIN_ROOT-based path resolution
   for go run script discovery.

See `.tdd/disposition-matrix.md` "Deferred" section for full list.
