# Red Proof: v1.8.0-ast-validator-and-audit-integrity

**Date:** 2026-05-10

## Output (verbatim — initial smoke before any green-phase code)

```text
Results: 484 passed, 13 failed
```

13 new acceptance tests for v1.8.0 ACs are RED. Plus 1 unexpected
PASS (`v18_max_per_cycle_zero_means_no_cap`) — currently passes
because no cap is enforced; after green-phase implementation the
test still passes (0 = no cap is the implemented semantics) and a
companion test (`v18_max_per_cycle_cap_blocks_at_threshold`)
verifies the inverse.

## RED test → AC mapping

| RED test | AC | What it pins |
|---|----|--------------|
| v18_ast_validator_go_compiles_and_runs | AC1.1, AC1.5 | Go file exists, `--version` works, < 5s budget |
| v18_ast_import_block_check_rejects_outside_block | AC1.2 | `import-block-check` subcommand rejects string-literal change outside import block |
| v18_ast_mech_sig_prop_check_rejects_helper_change | AC1.2 | `mech-sig-prop-check` rejects require.Equal → require.NoError |
| v18_ast_compile_fix_scope_uses_ast_not_regex | AC1.2 | `compile-fix-scope-check` distinguishes `XHelper` from `X` (AST identifier match, not substring) |
| v18_ast_schema_predicate_check_only_renames | AC1.2 | `schema-predicate-check` accepts pure rename, rejects helper change |
| v18_validator_dispatches_to_ast_helper | AC2.1 | Validator AND-gates regex + AST; AST catches `+    import "math"` indented inside func body that regex's `^[+-]\s*import\s` filter misses |
| v18_validator_ast_killswitch_falls_back_to_regex | AC2.1, AC6.2 | `TDD_AST_VALIDATOR_DISABLE=1` allows regex-only path AND emits stderr warning |
| v18_validator_no_go_binary_warns_and_falls_back | AC6.1, AC6.3 | Missing `go` binary triggers fallback + warning |
| v18_schema_predicate_correction_grant_and_validate | AC3.* | Grant helper accepts `--old-name` / `--new-name`; type persists in artifact |
| v18_max_per_cycle_cap_blocks_at_threshold | AC4.2, AC4.3 | 3 approved exceptions with `max_per_cycle: 2` denied at hook |
| v18_max_per_cycle_zero_means_no_cap | AC4.1 | 10 exceptions with `max_per_cycle: 0` not capped |
| v18_audit_chain_detects_tamper | AC5.2, AC5.3 | Tampered `prev_sha` rejects at hook |
| v18_audit_chain_intact_passes_verify | AC5.2 | `verify-audit-chain.sh` accepts intact chain |
| v18_audit_chain_grant_helper_writes_prev_sha | AC5.4 | Grant helper writes `prev_sha` field on each audit-log line |

## Why these tests prove the feature

- Each test isolates ONE behavior. Failure pinpoints which AC isn't
  satisfied.
- The AST tests (AC1) call `go run scripts/tdd/ast/validator.go
  <subcommand>` directly — no library indirection — so
  prerequisite gating ("Go file missing") is detected explicitly
  rather than silently dispatched to fallback.
- The dispatch test (`v18_validator_dispatches_to_ast_helper`)
  uses a payload regex genuinely cannot reject (`+    import
  "math"` inside a function body matches the import-line filter)
  but AST genuinely can. Without AST wired in, validator returns
  silent allow — test fails as expected.
- The killswitch + no-go tests both exercise the fallback path
  AND the warning, so a regression that silently degrades to
  regex without telling the operator is caught.
- The cap test pair (`v18_max_per_cycle_cap_blocks_at_threshold` +
  `v18_max_per_cycle_zero_means_no_cap`) covers both threshold
  enforcement and the explicit no-cap semantics.
- The audit-chain triplet (tamper detect / intact verify / grant
  helper writes prev_sha) covers the integrity invariant from
  three angles.

## Pre-implementation assumptions

- Bootstrap `.tdd/second-opinion-completed.md` permits Tier 1
  edits (require-tdd-state.sh) for this cycle's scope.
- v1.7.0 baseline carried: 469 v1.7.0-era tests still pass
  unchanged (hook + library are extended, not replaced).
- Go ≥1.26.2 available on the test host (per pack hard-dep
  matrix); `command -v go` returns 0.
