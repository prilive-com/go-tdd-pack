# Project-local TDD marker vocabulary

This block is generated from `.tdd/tdd-config.json` by
`scripts/tdd/build-second-opinion-context.sh`. The repo's TDD
ceremony uses the canonical markers below. The aliases section
lists deprecated names retained for backwards compatibility only.

## Canonical edit-time markers

- `Human approved spec: yes`
- `Red phase confirmed: yes`
- `Green phase authorized: yes`

## Canonical commit-time markers

- `Human approved spec: yes`
- `Red phase confirmed: yes`
- `Green phase authorized: yes`
- `Implementation reviewed: yes`

## Deprecated aliases

- `Human approved implementation: yes` → `Green phase authorized: yes` (deprecated alias)

## Reviewer instruction

If you think a marker is wrong, verify against `.tdd/tdd-config.json`
before producing a finding. Local config is canonical and beats your
training-data prior.
Markers listed in the `Deprecated aliases` section above are
backwards-compatibility aliases only — do NOT report the canonical
(non-deprecated) names as nonstandard or incorrect. The aliases
section is project-specific; any rename your project's
`tdd-config.json` documents takes precedence over your training-data
prior.
